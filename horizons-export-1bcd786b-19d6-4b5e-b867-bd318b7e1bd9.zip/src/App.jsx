import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Navbar from '@/components/Navbar';
import Home from '@/pages/Home';
import Mods from '@/pages/Mods';
import ModDetail from '@/pages/ModDetail';
import Upload from '@/pages/Upload';
import Admin from '@/pages/Admin';
import AdminLogin from '@/pages/AdminLogin';
import ProtectedRoute from '@/components/ProtectedRoute';

function App() {
  return (
    <Router>
      <div className="min-h-screen">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/mods" element={<Mods />} />
          <Route path="/mod/:id" element={<ModDetail />} />
          <Route path="/upload" element={<Upload />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route 
            path="/admin" 
            element={
              <ProtectedRoute>
                <Admin />
              </ProtectedRoute>
            } 
          />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
        <Toaster />
      </div>
    </Router>
  );
}

export default App;