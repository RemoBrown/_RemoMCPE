import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Settings, Trash2, Edit, Download, Star, Check, X, Clock, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const Admin = () => {
  const [mods, setMods] = useState([]);
  const [pendingMods, setPendingMods] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredMods, setFilteredMods] = useState([]);
  const [filteredPendingMods, setFilteredPendingMods] = useState([]);
  const [editingMod, setEditingMod] = useState(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const savedMods = JSON.parse(localStorage.getItem('mods') || '[]');
    const savedPendingMods = JSON.parse(localStorage.getItem('pendingMods') || '[]');
    setMods(savedMods);
    setPendingMods(savedPendingMods);
  }, []);

  useEffect(() => {
    setFilteredMods(
      mods.filter(mod =>
        mod.title.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
    setFilteredPendingMods(
      pendingMods.filter(mod =>
        mod.title.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }, [mods, pendingMods, searchTerm]);

  const handleDelete = (modId) => {
    const updatedMods = mods.filter(mod => mod.id !== modId);
    setMods(updatedMods);
    localStorage.setItem('mods', JSON.stringify(updatedMods));
    toast({
      title: "تم حذف المود بنجاح",
      description: "تم إزالة المود من القائمة",
    });
  };

  const handleEdit = (mod) => {
    setEditingMod({ ...mod });
    setIsEditDialogOpen(true);
  };

  const handleSaveEdit = () => {
    const updatedMods = mods.map(mod =>
      mod.id === editingMod.id ? editingMod : mod
    );
    setMods(updatedMods);
    localStorage.setItem('mods', JSON.stringify(updatedMods));
    setIsEditDialogOpen(false);
    setEditingMod(null);
    toast({
      title: "تم تحديث المود بنجاح",
      description: "تم حفظ التغييرات",
    });
  };

  const handleApprove = (modId) => {
    const modToApprove = pendingMods.find(mod => mod.id === modId);
    if (!modToApprove) return;

    const updatedPendingMods = pendingMods.filter(mod => mod.id !== modId);
    const approvedMod = { 
        ...modToApprove, 
        status: 'approved', 
        rating: modToApprove.rating || 5.0, 
        downloads: modToApprove.downloads || 0 
    };
    const updatedApprovedMods = [...mods, approvedMod];

    setPendingMods(updatedPendingMods);
    setMods(updatedApprovedMods);

    localStorage.setItem('pendingMods', JSON.stringify(updatedPendingMods));
    localStorage.setItem('mods', JSON.stringify(updatedApprovedMods));

    toast({
      title: "تمت الموافقة على المود بنجاح",
      description: `تم نشر مود "${modToApprove.title}".`,
    });
  };

  const handleReject = (modId) => {
    const modToReject = pendingMods.find(mod => mod.id === modId);
    if (!modToReject) return;
    
    const updatedPendingMods = pendingMods.filter(mod => mod.id !== modId);
    setPendingMods(updatedPendingMods);
    localStorage.setItem('pendingMods', JSON.stringify(updatedPendingMods));
    toast({
      variant: 'destructive',
      title: "تم رفض المود",
      description: `تم رفض مود "${modToReject.title}" وإزالته.`,
    });
  };
  
  const handleInputChange = (field, value) => {
    setEditingMod(prev => ({ ...prev, [field]: value }));
  };

  const formatDownloads = (downloads) => (downloads >= 1000 ? `${(downloads / 1000).toFixed(1)}K` : (downloads || 0).toString());

  const stats = [
    { label: 'المودات المنشورة', value: mods.length, icon: Check },
    { label: 'في انتظار المراجعة', value: pendingMods.length, icon: Clock },
    { label: 'إجمالي التحميلات', value: mods.reduce((sum, mod) => sum + (mod.downloads || 0), 0), icon: Download },
    { label: 'متوسط التقييم', value: (mods.reduce((sum, mod) => sum + (mod.rating || 0), 0) / mods.length || 0).toFixed(1), icon: Star },
  ];

  return (
    <>
      <Helmet>
        <title>لوحة الإدارة - MCPE Mods</title>
        <meta name="description" content="إدارة المودات والمحتوى في موقع MCPE Mods" />
      </Helmet>

      <div className="pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-center mb-12">
            <div className="w-20 h-20 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Settings size={40} className="text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-6">لوحة الإدارة</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">إدارة المودات والمحتوى بسهولة وفعالية.</p>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="glass-effect rounded-xl p-6 text-center">
                  <Icon size={32} className="mx-auto text-blue-400 mb-3" />
                  <div className="text-2xl font-bold text-white mb-1">{stat.label.includes('التحميلات') ? formatDownloads(stat.value) : stat.value}</div>
                  <div className="text-gray-400 text-sm">{stat.label}</div>
                </div>
              );
            })}
          </motion.div>

          <Tabs defaultValue="pending" className="w-full">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }}>
              <TabsList className="grid w-full grid-cols-2 glass-effect">
                <TabsTrigger value="pending">في انتظار المراجعة ({pendingMods.length})</TabsTrigger>
                <TabsTrigger value="published">المودات المنشورة ({mods.length})</TabsTrigger>
              </TabsList>
            </motion.div>
            
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.5 }} className="mt-6">
              <div className="glass-effect rounded-xl p-6 mb-8">
                <Input type="text" placeholder="ابحث في المودات..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="bg-white/5 border-white/10 text-white placeholder-gray-400" />
              </div>
            </motion.div>

            <TabsContent value="pending">
              <AdminTable title="المودات في انتظار المراجعة" mods={filteredPendingMods} onApprove={handleApprove} onReject={handleReject} isPending />
            </TabsContent>
            <TabsContent value="published">
              <AdminTable title="المودات المنشورة" mods={filteredMods} onEdit={handleEdit} onDelete={handleDelete} />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="glass-effect border-white/10 text-white max-w-2xl">
          <DialogHeader><DialogTitle className="text-2xl gradient-text">تحرير المود</DialogTitle></DialogHeader>
          {editingMod && (
            <div className="space-y-6 pt-4">
              <div className="space-y-2"><label className="text-white font-medium">العنوان</label><Input value={editingMod.title} onChange={(e) => handleInputChange('title', e.target.value)} className="bg-white/5 border-white/10 text-white" /></div>
              <div className="space-y-2"><label className="text-white font-medium">الوصف</label><textarea value={editingMod.description} onChange={(e) => handleInputChange('description', e.target.value)} rows={3} className="w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-white resize-none" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><label className="text-white font-medium">الفئة</label><select value={editingMod.category} onChange={(e) => handleInputChange('category', e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-md px-3 py-2 text-white"><option value="أدوات">أدوات</option><option value="مخلوقات">مخلوقات</option><option value="ديكور">ديكور</option><option value="مركبات">مركبات</option><option value="سحر">سحر</option><option value="أسلحة">أسلحة</option></select></div>
                <div className="space-y-2"><label className="text-white font-medium">التقييم</label><Input type="number" min="1" max="5" step="0.1" value={editingMod.rating} onChange={(e) => handleInputChange('rating', parseFloat(e.target.value))} className="bg-white/5 border-white/10 text-white" /></div>
              </div>
              <div className="flex justify-end space-x-4 pt-4"><Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="border-white/20 text-white hover:bg-white/10">إلغاء</Button><Button onClick={handleSaveEdit} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">حفظ التغييرات</Button></div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

const AdminTable = ({ title, mods, onEdit, onDelete, onApprove, onReject, isPending = false }) => {
  const formatDate = (dateString) => new Date(dateString).toLocaleDateString('ar-SA');
  const formatDownloads = (downloads) => (downloads >= 1000 ? `${(downloads / 1000).toFixed(1)}K` : (downloads || 0).toString());

  return (
    <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.6 }} className="glass-effect rounded-xl overflow-hidden">
      <div className="p-6 border-b border-white/10">
        <h2 className="text-2xl font-bold text-white">{title}</h2>
        <p className="text-gray-400 mt-2">عدد المودات: {mods.length}</p>
      </div>
      <div className="overflow-x-auto"><table className="w-full">
        <thead className="bg-white/5"><tr>
          <th className="text-right p-4 text-white font-semibold">المود</th>
          <th className="text-right p-4 text-white font-semibold">الفئة</th>
          {!isPending && <th className="text-right p-4 text-white font-semibold">التحميلات</th>}
          {!isPending && <th className="text-right p-4 text-white font-semibold">التقييم</th>}
          <th className="text-right p-4 text-white font-semibold">التاريخ</th>
          <th className="text-right p-4 text-white font-semibold">الإجراءات</th>
        </tr></thead>
        <tbody>
          {mods.map((mod, index) => (
            <motion.tr key={mod.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4, delay: index * 0.1 }} className="border-b border-white/5 hover:bg-white/5">
              <td className="p-4"><div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600/20 to-purple-600/20 rounded-lg flex-shrink-0 flex items-center justify-center">
                  {mod.image ? <img src={mod.image} alt={mod.title} className="w-full h-full object-cover rounded-lg" /> : <ImageIcon size={24} className="text-gray-500"/> }
                </div>
                <div><div className="text-white font-medium">{mod.title}</div><div className="text-gray-400 text-sm truncate max-w-xs">{mod.description}</div></div>
              </div></td>
              <td className="p-4"><span className="bg-blue-600/20 text-blue-400 px-2 py-1 rounded-full text-xs">{mod.category}</span></td>
              {!isPending && <td className="p-4 text-gray-300">{formatDownloads(mod.downloads)}</td>}
              {!isPending && <td className="p-4"><div className="flex items-center space-x-1"><Star size={14} className="text-yellow-400 fill-current" /><span className="text-gray-300">{mod.rating}</span></div></td>}
              <td className="p-4 text-gray-300">{formatDate(mod.date)}</td>
              <td className="p-4"><div className="flex items-center space-x-2">
                {isPending ? (
                  <>
                    <Button onClick={() => onApprove(mod.id)} className="bg-green-600 hover:bg-green-700 h-8 w-8" size="icon"><Check size={14} /></Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild><Button variant="destructive" className="bg-red-600 hover:bg-red-700 h-8 w-8" size="icon"><X size={14} /></Button></AlertDialogTrigger>
                      <AlertDialogContent className="glass-effect border-white/10 text-white"><AlertDialogHeader><AlertDialogTitle>هل أنت متأكد؟</AlertDialogTitle><AlertDialogDescription>سيتم رفض هذا المود وإزالته نهائياً. لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>إلغاء</AlertDialogCancel><AlertDialogAction onClick={() => onReject(mod.id)} className="bg-destructive text-destructive-foreground">رفض</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
                    </AlertDialog>
                  </>
                ) : (
                  <>
                    <Button variant="outline" size="icon" onClick={() => onEdit(mod)} className="border-white/20 text-white hover:bg-white/10 h-8 w-8"><Edit size={14} /></Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild><Button variant="outline" size="icon" className="border-red-500/20 text-red-400 hover:bg-red-500/10 h-8 w-8"><Trash2 size={14} /></Button></AlertDialogTrigger>
                      <AlertDialogContent className="glass-effect border-white/10 text-white"><AlertDialogHeader><AlertDialogTitle>هل أنت متأكد؟</AlertDialogTitle><AlertDialogDescription>سيتم حذف هذا المود نهائياً. لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>إلغاء</AlertDialogCancel><AlertDialogAction onClick={() => onDelete(mod.id)} className="bg-destructive text-destructive-foreground">حذف</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
                    </AlertDialog>
                  </>
                )}
              </div></td>
            </motion.tr>
          ))}
        </tbody>
      </table></div>
      {mods.length === 0 && (
        <div className="text-center py-12"><div className="text-6xl mb-4">📦</div><h3 className="text-2xl font-bold text-white mb-2">لا توجد مودات هنا</h3><p className="text-gray-400">هذه القائمة فارغة حالياً</p></div>
      )}
    </motion.div>
  );
};

export default Admin;