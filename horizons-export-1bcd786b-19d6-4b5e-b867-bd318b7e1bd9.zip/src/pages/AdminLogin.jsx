import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Lock, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const ADMIN_PASSWORD = 'iRaQ2005@#$';

const AdminLogin = () => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      sessionStorage.setItem('isAdminAuthenticated', 'true');
      toast({
        title: 'تم تسجيل الدخول بنجاح!',
        description: 'أهلاً بك في لوحة الإدارة.',
      });
      navigate('/admin');
    } else {
      setError('كلمة المرور غير صحيحة. الرجاء المحاولة مرة أخرى.');
      toast({
        variant: 'destructive',
        title: 'خطأ في تسجيل الدخول',
        description: 'كلمة المرور غير صحيحة.',
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>تسجيل دخول المشرف - MCPE Mods</title>
      </Helmet>
      <div className="min-h-screen flex items-center justify-center pt-16">
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="w-full max-w-md mx-auto p-8 glass-effect rounded-2xl shadow-2xl"
        >
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lock size={40} className="text-white" />
            </div>
            <h1 className="text-3xl font-bold gradient-text">دخول المشرف</h1>
            <p className="text-gray-400 mt-2">الرجاء إدخال كلمة المرور للوصول إلى لوحة الإدارة.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Input
                type="password"
                placeholder="كلمة المرور"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-white/5 border-white/10 text-white placeholder-gray-400 text-center text-lg h-12"
              />
              {error && <p className="text-red-400 text-sm text-center pt-2">{error}</p>}
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 text-lg neon-glow"
            >
              <LogIn className="mr-2" size={20} />
              دخول
            </Button>
          </form>
        </motion.div>
      </div>
    </>
  );
};

export default AdminLogin;