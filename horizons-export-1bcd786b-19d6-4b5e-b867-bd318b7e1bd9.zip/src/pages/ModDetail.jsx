import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Download, Star, Calendar, ArrowLeft, Share2, Heart, Flag, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ModDetail = () => {
  const { id } = useParams();
  const [mod, setMod] = useState(null);
  const [isLiked, setIsLiked] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const savedMods = localStorage.getItem('mods');
    if (savedMods) {
      const mods = JSON.parse(savedMods);
      const foundMod = mods.find(m => m.id.toString() === id);
      if (foundMod) {
        setMod({
          ...foundMod,
          author: 'مطور مجهول',
          version: foundMod.version || '1.0.0',
          size: '2.5 MB', // This can be calculated from fileData if needed
          compatibility: foundMod.compatibility || 'MCPE 1.20+',
          fullDescription: `${foundMod.description}\n\nهذا المود يضيف العديد من الميزات الرائعة إلى لعبة ماينكرافت بوكيت إديشن. تم تطويره بعناية فائقة لضمان أفضل تجربة لعب ممكنة.\n\nالميزات الرئيسية:\n• سهولة التركيب والاستخدام\n• متوافق مع أحدث إصدارات اللعبة\n• لا يؤثر على أداء اللعبة\n• آمن ومجرب من قبل آلاف اللاعبين`,
          screenshots: foundMod.screenshots || [],
        });
      }
    }
  }, [id]);

  const handleDownload = () => {
    if (!mod || !mod.fileData || !mod.fileName) {
      toast({
        variant: "destructive",
        title: "خطأ في التحميل",
        description: "ملف المود غير متوفر أو تالف.",
      });
      return;
    }
    try {
      const link = document.createElement('a');
      link.href = mod.fileData;
      link.download = mod.fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Increment download count
      const savedMods = JSON.parse(localStorage.getItem('mods') || '[]');
      const updatedMods = savedMods.map(m => m.id === mod.id ? { ...m, downloads: (m.downloads || 0) + 1 } : m);
      localStorage.setItem('mods', JSON.stringify(updatedMods));
      setMod(prev => ({...prev, downloads: (prev.downloads || 0) + 1}));

      toast({
        title: "بدأ التحميل!",
        description: `جاري تحميل ${mod.fileName}.`,
      });
    } catch (error) {
       toast({
        variant: "destructive",
        title: "فشل التحميل",
        description: "حدث خطأ غير متوقع أثناء محاولة تحميل الملف.",
      });
    }
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    toast({
      title: isLiked ? "تم إلغاء الإعجاب" : "تم الإعجاب بالمود",
      description: isLiked ? "تم إزالة المود من المفضلة" : "تم إضافة المود إلى المفضلة",
    });
  };

  const handleShare = async () => {
    const shareData = {
      title: mod.title,
      text: mod.description,
      url: window.location.href,
    };
    try {
      await navigator.share(shareData);
      toast({ title: "تمت المشاركة بنجاح!" });
    } catch (error) {
      try {
        await navigator.clipboard.writeText(window.location.href);
        toast({ title: "تم نسخ الرابط!", description: "يمكنك الآن مشاركته." });
      } catch (err) {
        toast({ title: "فشلت المشاركة", description: "متصفحك لا يدعم المشاركة أو النسخ.", variant: "destructive" });
      }
    }
  };

  const handleReport = () => {
    toast({
      title: "🚧 هذه الميزة غير متاحة حالياً",
      description: "لكن لا تقلق! يمكنك طلبها في رسالتك التالية! 🚀",
    });
  };

  const formatDate = (dateString) => new Date(dateString).toLocaleDateString('ar-SA');
  const formatDownloads = (downloads) => (downloads >= 1000 ? `${(downloads / 1000).toFixed(1)}K` : downloads.toString());

  if (!mod) {
    return (
      <div className="pt-24 pb-12"><div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center"><div className="text-6xl mb-4">❌</div><h1 className="text-3xl font-bold text-white mb-4">المود غير موجود</h1><p className="text-gray-400 mb-8">عذراً، لم يتم العثور على المود المطلوب</p><Link to="/mods"><Button className="bg-gradient-to-r from-blue-600 to-purple-600"><ArrowLeft className="mr-2" size={16} />العودة إلى المودات</Button></Link></div></div>
    );
  }

  return (
    <>
      <Helmet><title>{mod.title} - MCPE Mods</title><meta name="description" content={mod.description} /></Helmet>
      <div className="pt-24 pb-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }} className="mb-6"><Link to="/mods"><Button variant="outline" className="border-white/20 text-white hover:bg-white/10"><ArrowLeft className="mr-2" size={16} />العودة إلى المودات</Button></Link></motion.div>
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="glass-effect rounded-xl overflow-hidden">
                <div className="aspect-video bg-gradient-to-br from-blue-600/20 to-purple-600/20 flex items-center justify-center">
                  {mod.image && mod.image.startsWith('data:image') ? (
                    <img src={mod.image} alt={mod.title} className="w-full h-full object-cover" />
                  ) : mod.image ? (
                    <img  className="w-full h-full object-cover" alt={mod.title} src="https://images.unsplash.com/photo-1573325623776-58f994a9aeda" />
                  ) : (
                    <ImageIcon size={64} className="text-gray-500" />
                  )}
                </div>
                <div className="p-8">
                  <div className="flex items-start justify-between mb-6">
                    <div><h1 className="text-3xl md:text-4xl font-bold gradient-text mb-2">{mod.title}</h1><p className="text-gray-400">بواسطة {mod.author}</p></div>
                    <span className="bg-blue-600/20 text-blue-400 px-3 py-1 rounded-full text-sm flex-shrink-0">{mod.category}</span>
                  </div>
                  <div className="flex items-center gap-6 mb-6 text-sm text-gray-300">
                    <div className="flex items-center gap-2"><Download size={16} className="text-blue-400" /><span>{formatDownloads(mod.downloads)} تحميل</span></div>
                    <div className="flex items-center gap-2"><Star size={16} className="text-yellow-400 fill-current" /><span>{mod.rating}/5</span></div>
                    <div className="flex items-center gap-2"><Calendar size={16} className="text-gray-400" /><span>{formatDate(mod.date)}</span></div>
                  </div>
                  <p className="text-gray-300 text-lg leading-relaxed">{mod.description}</p>
                </div>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="glass-effect rounded-xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6">لقطات الشاشة</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {mod.screenshots && mod.screenshots.length > 0 ? mod.screenshots.map((screenshot, index) => (
                    <div key={index} className="aspect-video bg-gradient-to-br from-blue-600/20 to-purple-600/20 rounded-lg overflow-hidden">
                      <img src={screenshot} alt={`Screenshot ${index + 1} of ${mod.title}`} className="w-full h-full object-cover" />
                    </div>
                  )) : (
                    <p className="text-gray-400 col-span-2">لا توجد لقطات شاشة متاحة.</p>
                  )}
                </div>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} className="glass-effect rounded-xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6">الوصف التفصيلي</h2>
                <div className="prose prose-invert max-w-none">{mod.fullDescription.split('\n').map((paragraph, index) => (<p key={index} className="text-gray-300 mb-4 leading-relaxed">{paragraph}</p>))}</div>
              </motion.div>
            </div>
            <div className="space-y-6">
              <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }} className="glass-effect rounded-xl p-6 sticky top-24">
                <Button onClick={handleDownload} className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white py-4 text-lg mb-4 neon-glow"><Download className="mr-2" size={20} />تحميل المود</Button>
                <div className="flex gap-2 mb-6">
                  <Button variant="outline" size="icon" onClick={handleLike} className={`border-white/20 ${isLiked ? 'bg-red-600 text-white' : 'text-white hover:bg-white/10'}`}><Heart size={16} className={isLiked ? 'fill-current' : ''} /></Button>
                  <Button variant="outline" size="icon" onClick={handleShare} className="border-white/20 text-white hover:bg-white/10"><Share2 size={16} /></Button>
                  <Button variant="outline" size="icon" onClick={handleReport} className="border-white/20 text-white hover:bg-white/10"><Flag size={16} /></Button>
                </div>
                <div className="space-y-4 text-sm">
                  <div className="flex justify-between"><span className="text-gray-400">الإصدار:</span><span className="text-white">{mod.version}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">الحجم:</span><span className="text-white">{mod.size}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">التوافق:</span><span className="text-white">{mod.compatibility}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">المطور:</span><span className="text-white">{mod.author}</span></div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ModDetail;