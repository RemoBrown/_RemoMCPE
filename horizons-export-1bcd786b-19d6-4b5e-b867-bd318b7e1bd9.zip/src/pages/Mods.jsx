import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Search, Filter, Download, Star, Calendar, Grid, List, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Mods = () => {
  const [mods, setMods] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [viewMode, setViewMode] = useState('grid');
  const [filteredMods, setFilteredMods] = useState([]);

  const sampleMods = [
    { id: 1, title: 'Lucky Block Mod', description: 'أضف الحظ والمفاجآت إلى عالم ماينكرافت مع بلوكات الحظ المذهلة', downloads: 15420, rating: 4.8, date: '2024-06-15', category: 'أدوات', image: 'Lucky blocks with golden effects in Minecraft' },
    { id: 2, title: 'Dragon Mod', description: 'تنانين قوية وأسلحة جديدة لمغامرات لا تُنسى', downloads: 12350, rating: 4.9, date: '2024-06-10', category: 'مخلوقات', image: 'Epic dragon flying over Minecraft landscape' },
    { id: 3, title: 'Furniture Mod', description: 'أثاث وديكورات رائعة لتزيين منزلك في ماينكرافت', downloads: 8900, rating: 4.7, date: '2024-06-08', category: 'ديكور', image: 'Modern furniture in Minecraft house interior' },
    { id: 4, title: 'Cars Mod', description: 'سيارات وآليات متنوعة للتنقل السريع', downloads: 11200, rating: 4.6, date: '2024-06-05', category: 'مركبات', image: 'Sports cars and vehicles in Minecraft world' },
    { id: 5, title: 'Magic Mod', description: 'سحر وتعاويذ قوية لتجربة لعب سحرية', downloads: 9800, rating: 4.8, date: '2024-06-03', category: 'سحر', image: 'Magical spells and wizards in Minecraft' },
    { id: 6, title: 'Weapons Mod', description: 'أسلحة متطورة ومعدات قتالية جديدة', downloads: 13500, rating: 4.7, date: '2024-06-01', category: 'أسلحة', image: 'Advanced weapons and armor in Minecraft' }
  ];

  useEffect(() => {
    const savedMods = localStorage.getItem('mods');
    const allMods = savedMods ? JSON.parse(savedMods) : [];
    
    // Check if local storage is empty, if so, populate with sample data
    if (allMods.length === 0) {
      setMods(sampleMods);
      localStorage.setItem('mods', JSON.stringify(sampleMods));
    } else {
      setMods(allMods);
    }
  }, []);

  useEffect(() => {
    let filtered = mods.filter(mod =>
      mod.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      mod.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

    switch (sortBy) {
      case 'newest': filtered.sort((a, b) => new Date(b.date) - new Date(a.date)); break;
      case 'popular': filtered.sort((a, b) => b.downloads - a.downloads); break;
      case 'rating': filtered.sort((a, b) => b.rating - a.rating); break;
      default: break;
    }
    setFilteredMods(filtered);
  }, [mods, searchTerm, sortBy]);

  const formatDate = (dateString) => new Date(dateString).toLocaleDateString('ar-SA');
  const formatDownloads = (downloads) => (downloads >= 1000 ? `${(downloads / 1000).toFixed(1)}K` : downloads.toString());

  const ModCard = ({ mod }) => (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className={`glass-effect rounded-xl overflow-hidden card-hover ${viewMode === 'list' ? 'flex' : ''}`}
    >
      <div className={`${viewMode === 'list' ? 'w-48 flex-shrink-0' : 'aspect-video'} bg-gradient-to-br from-blue-600/20 to-purple-600/20 flex items-center justify-center`}>
        {mod.image && mod.image.startsWith('data:image') ? (
          <img src={mod.image} alt={`${mod.title} mod preview`} className="w-full h-full object-cover" />
        ) : mod.image ? (
          <img  className="w-full h-full object-cover" alt={mod.title} src="https://images.unsplash.com/photo-1573325623776-58f994a9aeda" />
        ) : (
          <ImageIcon size={48} className="text-gray-500" />
        )}
      </div>
      <div className={`p-6 ${viewMode === 'list' ? 'flex-1' : ''}`}>
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-xl font-bold text-white">{mod.title}</h3>
          <span className="text-xs bg-blue-600/20 text-blue-400 px-2 py-1 rounded-full">{mod.category}</span>
        </div>
        <p className="text-gray-400 mb-4 line-clamp-2">{mod.description}</p>
        <div className="flex items-center justify-between mb-4 text-sm text-gray-300">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1"><Download size={14} className="text-blue-400" /><span>{formatDownloads(mod.downloads)}</span></div>
            <div className="flex items-center space-x-1"><Star size={14} className="text-yellow-400 fill-current" /><span>{mod.rating}</span></div>
            <div className="flex items-center space-x-1"><Calendar size={14} className="text-gray-400" /><span>{formatDate(mod.date)}</span></div>
          </div>
        </div>
        <Link to={`/mod/${mod.id}`}><Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">عرض التفاصيل</Button></Link>
      </div>
    </motion.div>
  );

  return (
    <>
      <Helmet>
        <title>جميع المودات - MCPE Mods</title>
        <meta name="description" content="تصفح جميع مودات ماينكرافت بوكيت إديشن المتاحة. ابحث وصنف واعثر على المود المثالي لك." />
      </Helmet>
      <div className="pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-6">جميع المودات</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">اكتشف مجموعة واسعة من المودات المذهلة لماينكرافت بوكيت إديشن</p>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }} className="glass-effect rounded-xl p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="flex-1 w-full md:w-auto md:max-w-md"><div className="relative"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} /><Input type="text" placeholder="ابحث عن المودات..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10 bg-white/5 border-white/10 text-white placeholder-gray-400 w-full" /></div></div>
              <div className="flex items-center gap-4">
                <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="bg-white/5 border border-white/10 rounded-md px-3 py-2 text-white">
                  <option value="newest">الأحدث</option><option value="popular">الأكثر تحميلاً</option><option value="rating">الأعلى تقييماً</option>
                </select>
                <div className="flex items-center gap-2">
                  <Button variant={viewMode === 'grid' ? 'secondary' : 'outline'} size="icon" onClick={() => setViewMode('grid')}><Grid size={16} /></Button>
                  <Button variant={viewMode === 'list' ? 'secondary' : 'outline'} size="icon" onClick={() => setViewMode('list')}><List size={16} /></Button>
                </div>
              </div>
            </div>
          </motion.div>
          <div className="mb-6"><p className="text-gray-400">عرض {filteredMods.length} من أصل {mods.length} مود</p></div>
          <div className={`${viewMode === 'grid' ? 'grid md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}`}>
            {filteredMods.map((mod) => (<ModCard key={mod.id} mod={mod} />))}
          </div>
          {filteredMods.length === 0 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div><h3 className="text-2xl font-bold text-white mb-2">لم يتم العثور على نتائج</h3><p className="text-gray-400">جرب البحث بكلمات مختلفة</p>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
};

export default Mods;