
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Download, Star, Users, Zap, ArrowRight, Gamepad2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Home = () => {
  const stats = [
    { icon: Download, label: 'تحميلات', value: '50K+' },
    { icon: Star, label: 'مودات مميزة', value: '200+' },
    { icon: Users, label: 'مستخدمين', value: '10K+' },
    { icon: Zap, label: 'تحديثات يومية', value: '24/7' },
  ];

  const featuredMods = [
    {
      id: 1,
      title: 'Lucky Block Mod',
      description: 'أضف الحظ والمفاجآت إلى عالم ماينكرافت',
      downloads: '15K',
      rating: 4.8,
      image: 'Lucky blocks with golden effects in Minecraft'
    },
    {
      id: 2,
      title: 'Dragon Mod',
      description: 'تنانين قوية وأسلحة جديدة',
      downloads: '12K',
      rating: 4.9,
      image: 'Epic dragon flying over Minecraft landscape'
    },
    {
      id: 3,
      title: 'Furniture Mod',
      description: 'أثاث وديكورات رائعة لمنزلك',
      downloads: '8K',
      rating: 4.7,
      image: 'Modern furniture in Minecraft house interior'
    }
  ];

  return (
    <>
      <Helmet>
        <title>MCPE Mods - أفضل مودات ماينكرافت بوكيت إديشن</title>
        <meta name="description" content="اكتشف أفضل مودات ماينكرافت بوكيت إديشن. حمل مودات مجانية وآمنة لتحسين تجربة اللعب." />
      </Helmet>

      <div className="pt-16">
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-purple-900/20 to-pink-900/20"></div>
          
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <div className="floating-animation">
                <Gamepad2 size={80} className="mx-auto text-blue-400 mb-6" />
              </div>
              
              <h1 className="text-5xl md:text-7xl font-bold gradient-text mb-6">
                MCPE Mods
              </h1>
              
              <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mb-8">
                اكتشف عالماً لا محدوداً من المودات المذهلة لماينكرافت بوكيت إديشن
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/mods">
                  <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg neon-glow">
                    استكشف المودات
                    <ArrowRight className="ml-2" size={20} />
                  </Button>
                </Link>
                
                <Link to="/upload">
                  <Button variant="outline" size="lg" className="border-2 border-blue-500 text-blue-400 hover:bg-blue-500 hover:text-white px-8 py-4 text-lg">
                    ارفع مودك
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>

          {/* Floating Elements */}
          <div className="absolute top-20 left-10 w-20 h-20 bg-blue-500/20 rounded-full blur-xl floating-animation"></div>
          <div className="absolute bottom-20 right-10 w-32 h-32 bg-purple-500/20 rounded-full blur-xl floating-animation" style={{ animationDelay: '2s' }}></div>
          <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-pink-500/20 rounded-full blur-xl floating-animation" style={{ animationDelay: '4s' }}></div>
        </section>

        {/* Stats Section */}
        <section className="py-20 bg-black/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="text-center glass-effect rounded-xl p-6 card-hover"
                  >
                    <Icon size={40} className="mx-auto text-blue-400 mb-4" />
                    <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                    <div className="text-gray-400">{stat.label}</div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Featured Mods */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
                المودات المميزة
              </h2>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                اكتشف أحدث وأفضل المودات التي يحبها اللاعبون
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              {featuredMods.map((mod, index) => (
                <motion.div
                  key={mod.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="glass-effect rounded-xl overflow-hidden card-hover"
                >
                  <div className="aspect-video bg-gradient-to-br from-blue-600/20 to-purple-600/20 flex items-center justify-center">
                    <img  alt={`${mod.title} mod preview`} className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1573325623776-58f994a9aeda" />
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2">{mod.title}</h3>
                    <p className="text-gray-400 mb-4">{mod.description}</p>
                    
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <Download size={16} className="text-blue-400" />
                        <span className="text-sm text-gray-300">{mod.downloads}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star size={16} className="text-yellow-400 fill-current" />
                        <span className="text-sm text-gray-300">{mod.rating}</span>
                      </div>
                    </div>
                    
                    <Link to={`/mod/${mod.id}`}>
                      <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                        عرض التفاصيل
                      </Button>
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-blue-900/30 to-purple-900/30">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <h2 className="text-4xl md:text-5xl font-bold gradient-text">
                ابدأ رحلتك الآن
              </h2>
              <p className="text-xl text-gray-300">
                انضم إلى آلاف اللاعبين واكتشف مودات لا تُصدق
              </p>
              <Link to="/mods">
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-12 py-4 text-lg pulse-glow">
                  ابدأ الاستكشاف
                  <ArrowRight className="ml-2" size={20} />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;
