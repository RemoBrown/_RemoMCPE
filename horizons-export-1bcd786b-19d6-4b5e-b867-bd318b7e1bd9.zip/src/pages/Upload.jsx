import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Upload as UploadIcon, Image as ImageIcon, FileText, Tag, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';

const fileToBase64 = (file) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
});

const Upload = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    version: '',
    compatibility: '',
    file: null,
    images: []
  });
  const [imagePreviews, setImagePreviews] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const categories = [
    'أدوات', 'مخلوقات', 'ديكور', 'مركبات', 'سحر', 'أسلحة', 'طعام', 'مغامرات', 'تقنية', 'أخرى'
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        toast({
          variant: "destructive",
          title: "الملف كبير جداً!",
          description: "الحد الأقصى لحجم ملف المود هو 50 ميجابايت.",
        });
        return;
      }
      setFormData(prev => ({ ...prev, file: file }));
    }
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const validFiles = [];
    const newPreviews = [];

    for (const file of files) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit per image
        toast({
          variant: "destructive",
          title: "الصورة كبيرة جداً!",
          description: `حجم الصورة "${file.name}" يتجاوز 5 ميجابايت.`,
        });
        continue;
      }
      validFiles.push(file);
      newPreviews.push(URL.createObjectURL(file));
    }
    
    setFormData(prev => ({ ...prev, images: [...prev.images, ...validFiles] }));
    setImagePreviews(prev => [...prev, ...newPreviews]);
  };
  
  const removeImage = (index) => {
    const newImages = formData.images.filter((_, i) => i !== index);
    const newPreviews = imagePreviews.filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, images: newImages }));
    setImagePreviews(newPreviews);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsUploading(true);

    try {
      const imageBase64 = await Promise.all(formData.images.map(file => fileToBase64(file)));
      const fileBase64 = formData.file ? await fileToBase64(formData.file) : null;

      const savedPendingMods = localStorage.getItem('pendingMods');
      const pendingMods = savedPendingMods ? JSON.parse(savedPendingMods) : [];
      
      const newMod = {
        id: Date.now(),
        title: formData.title,
        description: formData.description,
        category: formData.category,
        version: formData.version,
        compatibility: formData.compatibility,
        downloads: 0,
        rating: 0,
        date: new Date().toISOString().split('T')[0],
        image: imageBase64.length > 0 ? imageBase64[0] : null,
        screenshots: imageBase64,
        fileData: fileBase64,
        fileName: formData.file ? formData.file.name : null,
        status: 'pending',
      };

      pendingMods.unshift(newMod);
      localStorage.setItem('pendingMods', JSON.stringify(pendingMods));

      toast({
        title: "تم إرسال المود للمراجعة! 👍",
        description: "سيتم مراجعة المود من قبل المشرفين قريباً.",
      });

      setFormData({ title: '', description: '', category: '', version: '', compatibility: '', file: null, images: [] });
      setImagePreviews([]);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "حدث خطأ!",
        description: "فشل رفع الملفات. الرجاء المحاولة مرة أخرى.",
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>رفع مود جديد - MCPE Mods</title>
        <meta name="description" content="ارفع مودك الخاص وشاركه مع مجتمع ماينكرافت بوكيت إديشن." />
      </Helmet>

      <div className="pt-24 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-center mb-12">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <UploadIcon size={40} className="text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-6">رفع مود جديد</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">شارك إبداعك مع مجتمع ماينكرافت واجعل الآخرين يستمتعون بمودك</p>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="glass-effect rounded-xl p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2"><FileText size={24} className="text-blue-400" />المعلومات الأساسية</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2"><Label htmlFor="title" className="text-white">عنوان المود *</Label><Input id="title" name="title" value={formData.title} onChange={handleInputChange} placeholder="أدخل عنوان المود" required className="bg-white/5 border-white/10 text-white placeholder-gray-400" /></div>
                  <div className="space-y-2"><Label htmlFor="category" className="text-white">الفئة *</Label><select id="category" name="category" value={formData.category} onChange={handleInputChange} required className="w-full h-10 bg-white/5 border border-white/10 rounded-md px-3 py-2 text-white"><option value="">اختر الفئة</option>{categories.map(category => (<option key={category} value={category} className="bg-gray-800">{category}</option>))}</select></div>
                </div>
                <div className="space-y-2"><Label htmlFor="description" className="text-white">الوصف *</Label><Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} placeholder="اكتب وصفاً مفصلاً عن المود وميزاته" rows={4} required className="bg-white/5 border-white/10 text-white placeholder-gray-400 resize-none" /></div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2"><Label htmlFor="version" className="text-white">إصدار المود</Label><Input id="version" name="version" value={formData.version} onChange={handleInputChange} placeholder="مثال: 1.0.0" className="bg-white/5 border-white/10 text-white placeholder-gray-400" /></div>
                  <div className="space-y-2"><Label htmlFor="compatibility" className="text-white">التوافق</Label><Input id="compatibility" name="compatibility" value={formData.compatibility} onChange={handleInputChange} placeholder="مثال: MCPE 1.20+" className="bg-white/5 border-white/10 text-white placeholder-gray-400" /></div>
                </div>
              </div>

              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2"><UploadIcon size={24} className="text-blue-400" />رفع الملفات</h2>
                <div className="space-y-4">
                  <div className="space-y-2"><Label htmlFor="modFile" className="text-white">ملف المود (.mcpack أو .zip) *</Label><div className="border-2 border-dashed border-white/20 rounded-lg p-8 text-center hover:border-blue-400 transition-colors"><input type="file" id="modFile" accept=".mcpack,.zip" onChange={handleFileUpload} className="hidden" required /><label htmlFor="modFile" className="cursor-pointer"><UploadIcon size={48} className="mx-auto text-gray-400 mb-4" /><p className="text-white mb-2">اضغط لرفع ملف المود</p><p className="text-gray-400 text-sm">يدعم .mcpack و .zip فقط</p>{formData.file && (<p className="text-blue-400 mt-2">تم اختيار: {formData.file.name}</p>)}</label></div></div>
                  <div className="space-y-2"><Label htmlFor="images" className="text-white">صور المود (صورة واحدة على الأقل مطلوبة)</Label><div className="border-2 border-dashed border-white/20 rounded-lg p-8 text-center hover:border-blue-400 transition-colors"><input type="file" id="images" accept="image/*" multiple onChange={handleImageUpload} className="hidden" required /><label htmlFor="images" className="cursor-pointer"><ImageIcon size={48} className="mx-auto text-gray-400 mb-4" /><p className="text-white mb-2">اضغط لرفع صور المود</p><p className="text-gray-400 text-sm">يمكنك رفع عدة صور</p></label></div>
                    {imagePreviews.length > 0 && (<div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4 mt-4">{imagePreviews.map((preview, index) => (<div key={index} className="relative group"><img src={preview} alt={`preview ${index}`} className="w-full h-24 object-cover rounded-lg" /><button type="button" onClick={() => removeImage(index)} className="absolute top-1 right-1 bg-red-600/80 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"><X size={12} /></button></div>))}</div>)}
                  </div>
                </div>
              </div>

              <div className="flex justify-center pt-6"><Button type="submit" disabled={isUploading} className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-12 py-4 text-lg neon-glow">{isUploading ? (<><div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>جاري الرفع...</>) : (<><Save className="mr-2" size={20} />إرسال للمراجعة</>)}</Button></div>
            </form>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} className="glass-effect rounded-xl p-8 mt-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2"><Tag size={24} className="text-blue-400" />إرشادات الرفع</h2>
            <div className="grid md:grid-cols-2 gap-6 text-gray-300">
              <div><h3 className="text-white font-semibold mb-3">متطلبات الملف:</h3><ul className="space-y-2 text-sm"><li>• يجب أن يكون الملف بصيغة .mcpack أو .zip</li><li>• الحد الأقصى لحجم الملف: 50 ميجابايت</li><li>• الحد الأقصى لحجم الصورة: 5 ميجابايت</li><li>• لا تحتوي على محتوى ضار أو غير مناسب</li></ul></div>
              <div><h3 className="text-white font-semibold mb-3">نصائح للنجاح:</h3><ul className="space-y-2 text-sm"><li>• اكتب عنواناً واضحاً وجذاباً</li><li>• أضف وصفاً مفصلاً عن الميزات</li><li>• ارفع صوراً عالية الجودة</li><li>• حدد الفئة المناسبة للمود</li></ul></div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Upload;